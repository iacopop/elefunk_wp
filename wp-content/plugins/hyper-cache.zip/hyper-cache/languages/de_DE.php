<?php

$hyper_labels['wp_cache_not_enabled'] = "Das WordPress Cachesystem ist nicht aktiv. Um es zu aktivieren bitte die folgende Zeile Code der Datei wp-config.php hinzuf&uuml;gen. Danke!";
$hyper_labels['configuration'] = "Konfiguration";
$hyper_labels['activate'] = "Cache aktiv?";
$hyper_labels['expire'] = "Ablauf des Cache nach";
$hyper_labels['minutes'] = "Minuten";
$hyper_labels['invalidate_single_posts'] = "Invalidate single posts";
$hyper_labels['invalidate_single_posts_desc'] = "Invalidate only the single cached post when modified (new comment, edited, ...)";
$hyper_labels['count'] = "Gecachte Seiten";
$hyper_labels['save'] = "Speichern";
$hyper_labels['gzip_compression'] = "Gzip compression";
$hyper_labels['gzip_compression_desc'] = "Enable gzip compression to serve copressed pages for gzip enabled browsers";
$hyper_labels['clear'] = "Cache l&ouml;schen";
$hyper_labels['compress_html'] = "Optimize HTML";

?>
